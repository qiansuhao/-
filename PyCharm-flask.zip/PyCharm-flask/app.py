
from flask import *

import pymysql as mysql
ya=1
host ="localhost"
user ="root"
password ="123456"
db = "test" #数据库
port = 3306 #numeber类型
dbHelp = mysql.connect(host=host,user=user,password=password,db=db,port=port)
c = dbHelp.cursor()

app = Flask(__name__)

@app.route('/',methods=['GET','POST'])#登录
def login():
    return render_template('login.html')

@app.route('/register/',methods=['GET'])#注册
def register():
    return render_template('register.html')

@app.route('/temp', methods=['POST'])#处理注册
def temp():
    name = request.form['name']
    account = request.form['account']
    password = request.form['password']
    address = request.form['address']
    insert_password(name,account,password, address)
    return render_template('success.html')

def insert_password(name,account, password, address):
    c.execute("INSERT INTO user(name,account,password,address) VALUES(%s,%s,%s,%s)",(name,account,password,address))
    dbHelp.commit()

def judge_if_in(account, password):
    c.execute("SELECT account, password from user")
    cursor=c.fetchall()
    for row in cursor:
        if row[0] == account and row[1] == password:
            return True
    return False

@app.route('/signin', methods=['POST','GET'])#处理登录
def signin():
    account = request.form.get("account")
    password = request.form.get("password")
    sql = "UPDATE user SET isnot='%s' WHERE account='%s'"
    c.execute(sql%("yes",account))
    print(c.fetchall())
    dbHelp.commit()
    if judge_if_in(account, password):
        return render_template("menus.html")
    return render_template("failure.html")

@app.route('/index01',methods=['POST','GET'])
def index01():
    sql = "SELECT * FROM menu WHERE id=1"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index02',methods=['POST','GET'])
def index02():
    sql = "SELECT * FROM menu WHERE id=2"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index03',methods=['POST','GET'])
def index03():
    sql = "SELECT * FROM menu WHERE id=3"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index04',methods=['POST','GET'])
def index04():
    sql = "SELECT * FROM menu WHERE id=4"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index05',methods=['POST','GET'])
def index05():
    sql = "SELECT * FROM menu WHERE id=5"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index06',methods=['POST','GET'])
def index06():
    sql = "SELECT * FROM menu WHERE id=6"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index07',methods=['POST','GET'])
def index07():
    sql = "SELECT * FROM menu WHERE id=7"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index08',methods=['POST','GET'])
def index08():
    sql = "SELECT * FROM menu WHERE id=8"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index09',methods=['POST','GET'])
def index09():
    sql = "SELECT * FROM menu WHERE id=9"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index10',methods=['POST','GET'])
def index10():
    sql = "SELECT * FROM menu WHERE id=10"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/index11',methods=['POST','GET'])
def index11():
    sql = "SELECT * FROM menu WHERE id=11"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/over',methods=['POST','GET'])
def over():
    account=request.args.get("account")
    print(account)
    sql="UPDATE user SET isnot='%s' where account='%s'"%('no',account)
    c.execute(sql)
    dbHelp.commit()
    return render_template("over.html")

@app.route('/index12',methods=['POST','GET'])
def index12():
    sql = "SELECT * FROM menu WHERE id=12"
    c.execute(sql)
    u = c.fetchall()
    return render_template('order.html',e=u)

@app.route('/display',methods=["post","get"])
def diaplay():
    sum = request.args.get("sum")
    sum = int(sum)
    s="select account from user where isnot='%s'"%('yes')
    c.execute(s)
    account=c.fetchall()
    sql = "INSERT INTO orders(id,account,total_price) value(%d,%s,%d)"
    c.execute(sql%(ya,account[0][0],sum))
    dbHelp.commit()
    sql2 = "SELECT * FROM orders,orderitems,user,menu WHERE menu.id=orderitems.food_id AND orderitems.order_id=orders.id=%d AND user.account = %s"%(ya,account[0][0])
    c.execute(sql2)
    list = c.fetchall()
    print(list)
    return render_template("display.html",list=list,)

@app.route('/order')#菜品详情
def order():
    return render_template("order.html")

@app.route('/menus')
def menus():
    return render_template("menus.html")

@app.route('/shopping')
def shopping():
    sql = "SELECT menu.address,menu.food_name,orderitems.quantity,menu.unit_price FROM menu,orderitems WHERE menu.id=orderitems.food_id AND orderitems.order_id=%d"%ya
    c.execute(sql)
    list = c.fetchall()
    sum = 0
    for li in list:
        sum = sum+li[2]*li[3]
    # 设一个变量
    # 计算总价
    # 存在以变量里
    return render_template("shopping.html",list=list,sum=sum)



@app.route('/add_shopping_cart',methods=['GET'])
def add_shopping_cart():#购买，加入购物车
    quantity = request.args.get("quantity")
    id =  request.args.get("id")
    id=int(id)
    quantity = int(quantity)
    sql = "SELECT food_id FROM orderitems"
    c.execute(sql)
    list = c.fetchall()
    hhh = False
    for li in list:
        if li[0] == id:
            hhh = True
            break
        elif li[0]==None:
            hhh = False
            break
    if hhh:
        sql = "update orderitems set quantity=quantity+%d where food_id=%d and order_id=%d"
        c.execute(sql%(quantity,id,ya))
        dbHelp.commit()
    else:
        sql = "INSERT INTO orderitems(food_id,order_id,quantity) VALUES(%d,%d,%d)"
        c.execute(sql%(id,ya,quantity))
        dbHelp.commit()#提交
    return render_template("add_success.html")



if __name__ == '__main__':
    app.run(debug=True)